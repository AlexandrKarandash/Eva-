(function () {
    'use strict';

    window.PaymentApi = window.PaymentApi || {};

    window.PaymentApi.cancelBooking = async function (orderId) {
        return window.PaymentCore.request(window.PaymentCore.CANCEL_API + encodeURIComponent(orderId) + '/', {
            method: 'POST',
            body: JSON.stringify({})
        });
    };
})();
