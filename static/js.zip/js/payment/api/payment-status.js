(function () {
    'use strict';

    window.PaymentApi = window.PaymentApi || {};

    window.PaymentApi.checkBookingStatus = async function (orderId) {
        return window.PaymentCore.request(window.PaymentCore.STATUS_API + encodeURIComponent(orderId) + '/', {
            method: 'GET'
        });
    };
})();